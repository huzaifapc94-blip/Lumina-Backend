import requests

BASE_URL = "http://localhost:8000"

def test_post_chat_api_streams_completions_with_valid_input():
    # Step 1: Get available models to obtain a valid model_id
    try:
        models_resp = requests.get(f"{BASE_URL}/api/models", timeout=30)
        assert models_resp.status_code == 200, f"Expected 200 from /api/models, got {models_resp.status_code}"
        models = models_resp.json()
        assert isinstance(models, list), "Expected models to be a list"
        assert len(models) > 0, "No models registered to use for chat test"
        model_id = models[0]["model_id"]

        # Prepare the request payload with message, model_id, optional history and images
        payload = {
            "message": "Hello, how are you?",
            "model_id": model_id,
            "history": [
                {"role": "user", "content": "Hello"},
                {"role": "assistant", "content": "Hi! How can I assist you today?"}
            ],
            "images": [
                "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAUA"
            ]
        }

        headers = {
            "Content-Type": "application/json",
            "Accept": "text/event-stream"
        }

        # Step 2: POST /api/chat to receive streamed completions
        resp = requests.post(f"{BASE_URL}/api/chat", json=payload, headers=headers, timeout=30, stream=True)
        assert resp.status_code == 200, f"Expected 200 status, got {resp.status_code}"
        assert resp.headers.get("Content-Type", "").startswith("text/event-stream"), \
            f"Expected Content-Type text/event-stream, got {resp.headers.get('Content-Type')}"

        # Step 3: Consume streaming response to confirm tokens come through SSE format "data: {token: ...}"
        # We'll just read first few events to verify
        event_count = 0
        for line in resp.iter_lines(decode_unicode=True):
            if line:
                # SSE data line expected to start with 'data:'
                assert line.startswith("data:"), f"Expected SSE line starting with 'data:', got: {line}"
                # json part after "data: "
                data_part = line[5:].strip()
                # Expecting JSON with at least key 'token'
                import json
                try:
                    token_payload = json.loads(data_part)
                    assert isinstance(token_payload, dict), "Parsed token payload is not a dict"
                    assert "token" in token_payload, "'token' key missing in SSE data payload"
                    event_count += 1
                    if event_count >= 5:
                        break  # enough events to assert streaming
                except Exception as e:
                    assert False, f"Failed to parse SSE data JSON: {e}"

        assert event_count > 0, "No SSE data events received in stream"

    except requests.RequestException as e:
        assert False, f"HTTP request failed: {e}"

test_post_chat_api_streams_completions_with_valid_input()