import requests

def test_post_chat_api_returns_error_when_api_key_not_configured():
    base_url = "http://localhost:8000"
    models_url = f"{base_url}/api/models"
    try:
        models_response = requests.get(models_url, timeout=10)
        models_response.raise_for_status()
        models = models_response.json()
    except requests.RequestException as e:
        assert False, f"Failed to get models: {e}"

    if not models or not isinstance(models, list):
        assert False, "Models list is empty or invalid, cannot test chat API with valid model_id"

    model_id = models[0].get("model_id")
    assert model_id, "Model object does not contain 'model_id'"

    url = f"{base_url}/api/chat"
    headers = {
        "Content-Type": "application/json"
    }
    payload = {
        "message": "Hello",
        "model_id": model_id
    }
    try:
        response = requests.post(url, json=payload, headers=headers, timeout=30)
    except requests.RequestException as e:
        assert False, f"Request failed: {e}"

    assert response.status_code == 500, f"Expected status code 500 but got {response.status_code}"
    try:
        json_resp = response.json()
    except ValueError:
        json_resp = None

    error_msg_contains = False
    if json_resp and isinstance(json_resp, dict):
        error_msg_contains = any(
            "api key not configured" in str(value).lower()
            for value in json_resp.values()
        )
    assert error_msg_contains, "Response does not contain 'API key not configured' error message."

test_post_chat_api_returns_error_when_api_key_not_configured()
