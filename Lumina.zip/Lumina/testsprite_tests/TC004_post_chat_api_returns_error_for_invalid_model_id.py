import requests

def test_post_chat_api_returns_error_for_invalid_model_id():
    base_url = "http://localhost:8000"
    endpoint = "/api/chat"
    url = base_url + endpoint

    headers = {
        "Content-Type": "application/json"
    }
    payload = {
        "message": "Hello, how are you?",
        "model_id": "invalid-model-id-1234"
    }
    try:
        response = requests.post(url, json=payload, headers=headers, timeout=30)
    except requests.RequestException as e:
        assert False, f"Request failed: {e}"

    assert response.status_code == 400, f"Expected status code 400 but got {response.status_code}"
    try:
        json_response = response.json()
    except ValueError:
        assert False, "Response is not valid JSON"

    assert "invalid model_id" in response.text.lower() or "invalid model_id" in str(json_response).lower(), \
        "Response does not contain expected invalid model_id error message"

test_post_chat_api_returns_error_for_invalid_model_id()