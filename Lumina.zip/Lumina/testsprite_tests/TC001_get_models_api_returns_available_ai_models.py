import requests

BASE_URL = "http://localhost:8000"
TIMEOUT = 30

def test_get_models_api_returns_available_ai_models():
    url = f"{BASE_URL}/api/models"
    headers = {
        "Accept": "application/json"
    }
    try:
        response = requests.get(url, headers=headers, timeout=TIMEOUT)
        response.raise_for_status()
    except requests.RequestException as e:
        assert False, f"Request failed: {e}"

    assert response.status_code == 200, f"Expected status code 200 but got {response.status_code}"
    
    try:
        models = response.json()
    except ValueError:
        assert False, "Response is not valid JSON"

    assert isinstance(models, list), f"Response JSON is not a list but {type(models)}"

    if len(models) > 0:
        for model in models:
            assert isinstance(model, dict), f"Model item is not a dict: {model}"
            assert "provider" in model, "Model object missing 'provider' field"
            assert isinstance(model["provider"], str), "'provider' field is not a string"
            assert "model_id" in model, "Model object missing 'model_id' field"
            assert isinstance(model["model_id"], str), "'model_id' field is not a string"
            assert "display_name" in model, "Model object missing 'display_name' field"
            assert isinstance(model["display_name"], str), "'display_name' field is not a string"
            assert "optimizations" in model, "Model object missing 'optimizations' field"
            # optimizations could be any type as per schema, but often dict or list; just check presence here

test_get_models_api_returns_available_ai_models()