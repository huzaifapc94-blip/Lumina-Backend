import requests

BASE_URL = "http://localhost:8000"

def test_get_root_serves_frontend_html_page():
    url = f"{BASE_URL}/"
    headers = {
        "Accept": "text/html"
    }
    try:
        response = requests.get(url, headers=headers, timeout=30)
    except requests.RequestException as e:
        assert False, f"Request to {url} failed: {e}"
    assert response.status_code == 200, f"Expected status code 200 but got {response.status_code}"
    content_type = response.headers.get("Content-Type", "")
    assert "text/html" in content_type.lower(), f"Expected 'text/html' in Content-Type but got '{content_type}'"
    assert len(response.text) > 0, "Response HTML content is empty"

test_get_root_serves_frontend_html_page()