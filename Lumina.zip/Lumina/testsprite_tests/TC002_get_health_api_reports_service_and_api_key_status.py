import requests

def test_get_health_api_reports_service_and_api_key_status():
    base_url = "http://localhost:8000"
    url = f"{base_url}/api/health"
    headers = {
        "Accept": "application/json"
    }

    try:
        response = requests.get(url, headers=headers, timeout=30)
        response.raise_for_status()
    except requests.RequestException as e:
        assert False, f"Request to {url} failed: {e}"

    assert response.status_code == 200, f"Expected status code 200, got {response.status_code}"

    try:
        data = response.json()
    except ValueError:
        assert False, "Response is not valid JSON"

    assert isinstance(data, dict), f"Expected response JSON to be an object, got {type(data)}"

    assert "status" in data, "'status' field missing in response JSON"
    assert isinstance(data["status"], str), "'status' field should be a string"

    assert "api_key_configured" in data, "'api_key_configured' field missing in response JSON"
    assert isinstance(data["api_key_configured"], bool), "'api_key_configured' field should be a boolean"


test_get_health_api_reports_service_and_api_key_status()